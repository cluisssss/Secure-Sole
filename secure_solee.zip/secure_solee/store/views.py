from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required
from django_otp.plugins.otp_totp.models import TOTPDevice
from django.views.decorators.http import require_POST
from django.contrib import messages

# 2FA Setup View
@login_required
def setup_2fa(request):
    # Skip 2FA setup if user used Google login
    if request.user.socialaccount_set.exists():
        request.session['otp_verified'] = True
        return redirect('home')  # Go directly to home

    # Check if user already has a confirmed TOTP device
    device = TOTPDevice.objects.filter(user=request.user, confirmed=True).first()
    if not device:
        # Create a new TOTP device
        device = TOTPDevice.objects.create(user=request.user, confirmed=True)
        request.session['otp_verified'] = False  # Mark as unverified

    otp_uri = device.config_url
    return render(request, 'store/setup_2fa.html', {'otp_uri': otp_uri})


# 2FA Verification View
@login_required
@require_POST
def verify_2fa(request):
    token = request.POST.get('otp_token')
    device = TOTPDevice.objects.filter(user=request.user, confirmed=True).first()

    if device and device.verify_token(token):
        request.session['otp_verified'] = True
        return redirect('home')
    else:
        return render(request, 'store/setup_2fa.html', {
            'otp_uri': device.config_url,
            'error': 'Invalid token. Please try again.'
        })

# Register View
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')  # Redirect to login after successful registration
    else:
        form = UserCreationForm()
    return render(request, 'store/register.html', {'form': form})

# Login View
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            return redirect('setup_2fa')
    else:
        form = AuthenticationForm()
    return render(request, 'store/login.html', {'form': form})

# Home View
@login_required
def home_view(request):
    if not request.session.get('otp_verified', False):
        if not request.user.socialaccount_set.exists():
            return redirect('setup_2fa')
        else:
            request.session['otp_verified'] = True  # Set it to avoid loop

    return render(request, 'store/home.html')
    
def logout_view(request):
    logout(request)
    # Clear the session explicitly
    request.session.flush()  
    return redirect('login')


# Product View (Example)
# views.py

def product_view(request):
    brand_filter = request.GET.get('brand')

    products = [
        {'id': 1, 'name': 'Reebok ATR Chill Sneaker', 'brand': 'Reebok', 'price': 59.99, 'image': 'https://images.openai.com/thumbnails/79c12c90c144aad51d57fca6375951ea.webp'},
        {'id': 2, 'name': 'Reebok Floatride Energy 6', 'brand': 'Reebok', 'price': 79.99, 'image': 'https://images.openai.com/thumbnails/3c02529e1e6583ccf331b6ab6252e406.webp'},
        {'id': 3, 'name': 'Reebok Royal BB4500 Hi2 Sneakers', 'brand': 'Reebok', 'price': 45.49, 'image': 'https://images.openai.com/thumbnails/a447a49727fd9f9b5684d1c36f05f5f6.webp'},
        {'id': 4, 'name': 'New Balance Elite Runner X1', 'brand': 'New Balance', 'price': 179.99, 'image': 'https://images-na.ssl-images-amazon.com/images/I/719wghvbPEL.jpg'},
        {'id': 5, 'name': 'New Balance AeroTech 5 ', 'brand': 'New Balance', 'price': 249.99, 'image': 'https://m.media-amazon.com/images/I/81aTS7ROp-L._AC_SL1500_.jpg'},
        {'id': 6, 'name': 'New Balance 530', 'brand': 'New Balance', 'price': 200.99, 'image': 'https://shoenami.com.ph/cdn/shop/files/MR530SH-01.jpg?v=1717153349'},
        {'id': 7, 'name': 'Nike UltraBoost', 'brand': 'Nike', 'price': 69.99, 'image': 'https://shoenami.com.ph/cdn/shop/products/adidasUltraboost21J_CoreBlackCoreBlackCoreBlack_FY5390-3.jpg?v=1656661078'},
        {'id': 8, 'name': 'Nike RS-X', 'brand': 'Nike', 'price': 79.99, 'image': 'https://m.media-amazon.com/images/I/51RTG1X8UAL._AC_SL1000_.jpg'},
        {'id': 9, 'name': 'Nike Classic', 'brand': 'Nike', 'price': 59.99, 'image': 'https://static.nike.com/a/images/t_PDP_936_v1/f_auto,q_auto:eco/fcd8f4ec-1a32-4020-996e-8b8367edae34/NIKE+SB+FC+CLASSIC.png'}, 
        {'id': 10, 'name': 'Puma Vortex SpeedRunner 5000', 'brand': 'Puma', 'price': 189.99, 'image': 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_2000,h_2000/global/392593/02/sv01/fnd/PHL/fmt/png/Teveris-NITRO-Vortex-Sneakers'},
        {'id': 11, 'name': 'Puma ThunderStrike Fusion', 'brand': 'Puma', 'price': 219.99, 'image': 'https://cdn.shopify.com/s/files/1/0603/3031/1875/products/main-square_3f18bd28-59f1-4813-95d2-618fa335e2e3_540x.jpg?=75&v=1690442506'},
        {'id': 12, 'name': 'Puma AeroPulse Xtreme', 'brand': 'Puma', 'price': 249.99, 'image': 'https://images.puma.com/image/upload/f_auto,q_auto,b_rgb:fafafa,w_2000,h_2000/global/393271/02/sv01/fnd/PHL/fmt/png/Slipstream-Hi-Xtreme-Sneakers'},
        {'id': 13, 'name': 'Adidas TurboBoost UltraX', 'brand': 'Adidas', 'price': 199.99, 'image': 'https://www.shooos.com/media/catalog/product/cache/2/image/1350x778/9df78eab33525d08d6e5fb8d27136e95/a/d/adidas-ultraboost-20-fv83191.jpg'},
        {'id': 14, 'name': 'Adidas HyperCharge RS-X2', 'brand': 'Adidas', 'price': 219.99, 'image': 'https://assets.adidas.com/images/w_600,f_auto,q_auto/c22a22aa144941789482ad1f01884f78_9366/Response_Super_2.0_Shoes_Black_H04562_01_standard.jpg'},
        {'id': 15, 'name': 'Adidas QuantumFlex Boost', 'brand': 'Adidas', 'price': 249.99, 'image': 'https://barofashion.com/wp-content/uploads/2025/02/b9.jpg'},
    ]
    all_brands = sorted(set(p['brand'] for p in products))

    if brand_filter:
        products = [p for p in products if p['brand'].lower() == brand_filter.lower()]

    return render(request, 'store/product.html', {
        'products': products,
        'brands': all_brands,
        'selected_brand': brand_filter
    })


# Checkout View
def checkout_view(request):
    cart = request.session.get('cart', [])
    if not cart:
        return redirect('product')

    total_price = sum(item['price'] for item in cart)
    return render(request, 'store/checkout.html', {'cart': cart, 'total_price': total_price})

# Add to Cart View
def add_to_cart(request):
    if request.method == 'POST':
        product_id = int(request.POST.get('product_id', 0))

        products = {
        1: {'name': 'Reebok Stormflyer 3000', 'brand': 'Reebok', 'price': 59.99},
        2: {'name': 'Reebok HyperBoost V2', 'brand': 'Reebok', 'price': 79.99},
        3: {'name': 'Reebok TurboCharge RS-X', 'brand': 'Reebok', 'price': 45.49},
        4: {'name': 'New Balance Elite Runner X1', 'brand': 'New Balance', 'price': 179.99},
        5: {'name': 'New Balance AeroTech 5000', 'brand': 'New Balance', 'price': 249.99},
        6: {'name': 'New Balance 530', 'brand': 'New Balance', 'price': 200.99},
        7: {'name': 'Nike UltraBoost', 'brand': 'Nike', 'price': 69.99},
        8: {'name': 'Nike RS-X', 'brand': 'Nike', 'price': 79.99},
        9: {'name': 'Nike Classic', 'brand': 'Nike', 'price': 59.99},
        10:{'name': 'Puma Vortex SpeedRunner 5000', 'brand': 'Puma', 'price': 189.99},
        11:{'name': 'Puma ThunderStrike Fusion', 'brand': 'Puma', 'price': 219.99},
        12:{'name': 'Puma AeroPulse Xtreme', 'brand': 'Puma', 'price': 249.99},
        13:{'name': 'Adidas TurboBoost UltraX', 'brand': 'Adidas', 'price': 199.99},
        14:{'name': 'Adidas HyperCharge RS-X2', 'brand': 'Adidas', 'price': 219.99},
        15:{'name': 'Adidas QuantumFlex Boost', 'brand': 'Adidas', 'price': 249.99},
        }

        product = products.get(product_id)

        if product:
            cart = request.session.get('cart', [])

            if not isinstance(cart, list):
                cart = []
            cart.append(product)
            request.session['cart'] = cart
            return redirect('checkout')
    return redirect('product')

# Remove from Cart View
@require_POST
def remove_from_cart(request):
    index = int(request.POST.get('index', -1))
    cart = request.session.get('cart', [])
    if 0 <= index < len(cart):
        del cart[index]
        request.session['cart'] = cart
    return redirect('checkout')
