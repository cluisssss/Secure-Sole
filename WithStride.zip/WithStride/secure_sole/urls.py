from django.contrib import admin
from django.urls import path, include
from rest_framework.routers import DefaultRouter
from store.views import ProductViewSet # This is the new API view we added
from rest_framework_simplejwt.views import (
    TokenObtainPairView,
    TokenRefreshView,
)

# 1. Setup the REST API Router (Requirement #2: API Implementation)
# This handles the /api/products/ endpoints automatically
router = DefaultRouter()
router.register(r'products', ProductViewSet, basename='product-api')

urlpatterns = [
    # --- YOUR ORIGINAL PATHS (Preserved) ---
    path('admin/', admin.site.urls),           # <--- ADMIN IS STILL HERE
    path('', include('store.urls')),          # Your main store logic
    path('accounts/', include('allauth.urls')), # Google/Social login

    # --- NEW SYSTEM INTEGRATION PATHS (Added) ---
    
    # 2. RESTful API Endpoints (Requirement #2 & #3)
    # This exposes your inventory as a JSON API for system integration
    path('api/', include(router.urls)),

    # 3. JWT Authentication Endpoints (Requirement #2: Secure Authentication)
    # Allows external systems to login and get a Secure Token
    path('api/token/', TokenObtainPairView.as_view(), name='token_obtain_pair'),
    path('api/token/refresh/', TokenRefreshView.as_view(), name='token_refresh'),
]