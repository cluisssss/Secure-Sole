from django.contrib import admin
from .models import UserActivityLog, Product # ✅ Added Product model

# --- Product Admin (Requirement #4 & #7) ---
# This allows you to manage your shoe inventory through the dashboard
@admin.register(Product)
class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'brand', 'price', 'stock') # Shows these columns in the list
    list_filter = ('brand',) # Allows filtering by Brand on the right sidebar
    search_fields = ('name', 'brand') # Adds a search bar for shoes

# --- Activity Log Admin (Requirement #7: Monitoring) ---
@admin.register(UserActivityLog)
class UserActivityLogAdmin(admin.ModelAdmin):
    list_display = ('user', 'action', 'timestamp')
    list_filter = ('action', 'timestamp')
    search_fields = ('user__username', 'action')