from django.db.models.signals import post_save
from django.dispatch import receiver
from .models import UserActivityLog

@receiver(post_save, sender=UserActivityLog)
def orchestration_layer(sender, instance, created, **kwargs):
    if created and instance.action == 'checkout_start':
        # This simulates a Middleware/Orchestration layer 
        # communicating with an external Inventory system.
        print(f"MIDDLEWARE: Reserving stock in ERP for {instance.user.username}")