from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout
from django.contrib.auth.decorators import login_required, user_passes_test
from django_otp.plugins.otp_totp.models import TOTPDevice
from django.views.decorators.http import require_POST
from django.contrib import messages
from django_ratelimit.decorators import ratelimit
from django.utils.timezone import now

from .models import UserActivityLog, Product

# --- API IMPORTS ---
from rest_framework import viewsets, permissions
from rest_framework_simplejwt.authentication import JWTAuthentication
from .serializers import ProductSerializer

# =========================================================
# PRODUCT API (JWT SECURED)
# =========================================================
class ProductViewSet(viewsets.ModelViewSet):
    queryset = Product.objects.all()
    serializer_class = ProductSerializer
    permission_classes = [permissions.IsAuthenticated]
    authentication_classes = [JWTAuthentication]


# =========================================================
# ADMIN DASHBOARD
# =========================================================
def is_admin_user(user):
    return user.is_staff

@user_passes_test(is_admin_user)
def admin_dashboard(request):
    logs = UserActivityLog.objects.all().order_by('-timestamp')
    return render(request, 'store/dashboard.html', {'logs': logs})


# =========================================================
# RECOMMENDATION SYSTEM
# =========================================================
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

def get_recommended_products(product_id, top_n=3):
    db_products = list(Product.objects.all())
    if not db_products:
        return []

    product_descriptions = [f"{p.name} {p.brand}" for p in db_products]

    vectorizer = TfidfVectorizer()
    tfidf_matrix = vectorizer.fit_transform(product_descriptions)

    try:
        target_product = Product.objects.get(id=product_id)
        product_index = db_products.index(target_product)
    except (Product.DoesNotExist, ValueError):
        return []

    cosine_similarities = cosine_similarity(tfidf_matrix[product_index], tfidf_matrix).flatten()
    related_indices = cosine_similarities.argsort()[-top_n-1:-1][::-1]

    return [db_products[i] for i in related_indices]


# =========================================================
# 2FA SETUP
# =========================================================
@login_required
def setup_2fa(request):
    if request.user.socialaccount_set.exists():
        request.session['otp_verified'] = True
        return redirect('home')

    device = TOTPDevice.objects.filter(user=request.user, confirmed=True).first()
    if not device:
        device = TOTPDevice.objects.create(user=request.user, confirmed=True)
        request.session['otp_verified'] = False

    otp_uri = device.config_url
    return render(request, 'store/setup_2fa.html', {'otp_uri': otp_uri})


# =========================================================
# 2FA VERIFY
# =========================================================
@login_required
@require_POST
@ratelimit(key='ip', rate='5/m', block=True)
def verify_2fa(request):
    token = request.POST.get('otp_token')
    device = TOTPDevice.objects.filter(user=request.user, confirmed=True).first()

    if device and device.verify_token(token):
        request.session['otp_verified'] = True
        UserActivityLog.objects.create(user=request.user, action='2fa_success')
        return redirect('home')
    else:
        UserActivityLog.objects.create(user=request.user, action='2fa_failure')
        messages.error(request, 'Invalid token. Please try again.')
        return redirect('setup_2fa')


# =========================================================
# AUTH VIEWS
# =========================================================
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('login')
    else:
        form = UserCreationForm()

    return render(request, 'store/register.html', {'form': form})


@ratelimit(key='ip', rate='5/m', block=True)
def login_view(request):
    if request.method == 'POST':
        form = AuthenticationForm(request, data=request.POST)
        if form.is_valid():
            user = form.get_user()
            login(request, user)
            UserActivityLog.objects.create(user=user, action='login', timestamp=now())
            return redirect('setup_2fa')
        else:
            username = request.POST.get('username')
            from django.contrib.auth.models import User
            try:
                user = User.objects.get(username=username)
                UserActivityLog.objects.create(user=user, action='failed_login', timestamp=now())
            except User.DoesNotExist:
                pass
    else:
        form = AuthenticationForm()

    return render(request, 'store/login.html', {'form': form})


@login_required
def home_view(request):
    if not request.session.get('otp_verified', False):
        if not request.user.socialaccount_set.exists():
            return redirect('setup_2fa')
        request.session['otp_verified'] = True

    return render(request, 'store/home.html')


def logout_view(request):
    logout(request)
    request.session.flush()
    return redirect('login')


# =========================================================
# PRODUCT PAGE
# =========================================================
def product_view(request):
    brand_filter = request.GET.get('brand')
    viewed_id = request.GET.get('viewed')

    all_products = Product.objects.all()
    all_brands = sorted(set(all_products.values_list('brand', flat=True)))

    filtered_products = (
        all_products.filter(brand__iexact=brand_filter)
        if brand_filter else all_products
    )

    recommended = []
    if viewed_id and viewed_id.isdigit():
        recommended = get_recommended_products(int(viewed_id))

    return render(request, 'store/product.html', {
        'products': filtered_products,
        'brands': all_brands,
        'selected_brand': brand_filter,
        'recommended': recommended
    })


# =========================================================
# CART VIEW (THIS FIXES YOUR ERROR)
# =========================================================
def cart_view(request):
    cart = request.session.get('cart', [])
    total_price = sum(float(item['price']) for item in cart)

    return render(request, 'store/cart.html', {
        'cart': cart,
        'total_price': total_price
    })


# =========================================================
# ADD TO CART
# =========================================================
def add_to_cart(request):
    if request.method == 'POST':
        product_id = request.POST.get('product_id')
        product_obj = Product.objects.filter(id=product_id).first()

        if product_obj:
            product_data = {
                'id': product_obj.id,
                'name': product_obj.name,
                'brand': product_obj.brand,
                'price': str(product_obj.price),
                'image': product_obj.image_url
            }

            cart = request.session.get('cart', [])
            cart.append(product_data)

            request.session['cart'] = cart
            request.session.modified = True

            return redirect('cart')

    return redirect('product')


# =========================================================
# CHECKOUT
# =========================================================
def checkout_view(request):
    cart = request.session.get('cart', [])

    if not cart:
        return redirect('product')

    total_price = sum(float(item['price']) for item in cart)

    UserActivityLog.objects.create(
        user=request.user,
        action='checkout_start',
        details=f"Cart value: {total_price}"
    )

    return render(request, 'store/checkout.html', {
        'cart': cart,
        'total_price': total_price
    })


# =========================================================
# REMOVE FROM CART
# =========================================================
@require_POST
def remove_from_cart(request):
    index = int(request.POST.get('index', -1))
    cart = request.session.get('cart', [])

    if 0 <= index < len(cart):
        del cart[index]
        request.session['cart'] = cart
        request.session.modified = True

    return redirect('cart')