from django.db import models
from django.contrib.auth.models import User

class Product(models.Model):
    name = models.CharField(max_length=255)
    brand = models.CharField(max_length=100)
    price = models.DecimalField(max_digits=10, decimal_places=2)
    image_url = models.URLField()
    stock = models.IntegerField(default=10) # Inventory Integration

    def __str__(self):
        return self.name

class UserActivityLog(models.Model):
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    action = models.CharField(max_length=50) 
    details = models.TextField(blank=True, null=True) # For transaction tracking
    timestamp = models.DateTimeField(auto_now_add=True)